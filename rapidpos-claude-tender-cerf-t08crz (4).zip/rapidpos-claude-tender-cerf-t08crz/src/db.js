// ============================================================
// src/db.js — SQLite database layer
// ------------------------------------------------------------
// Uses Node's built-in synchronous SQLite (node:sqlite), which maps
// cleanly onto the original PHP/PDO code. A thin PDO-like wrapper
// (prepare/execute/fetch/fetchAll/fetchColumn/query/exec/lastInsertId +
// transactions) lets the router read almost identically to the PHP.
// ============================================================
'use strict';

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.POS_DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = process.env.POS_DB_FILE || path.join(DATA_DIR, 'pos.db');

const raw = new DatabaseSync(DB_FILE);
raw.exec('PRAGMA journal_mode = WAL;');
raw.exec('PRAGMA foreign_keys = ON;');

// ── Normalise bind values for node:sqlite ────────────────────
// node:sqlite only accepts null | number | bigint | string | Uint8Array.
function norm(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'number') return v;
  if (typeof v === 'bigint') return v;
  if (v instanceof Uint8Array) return v;
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

// PHP's PDOStatement::fetch() returns false when exhausted — we mirror that.
class Result {
  constructor(rows, info) {
    this._rows = rows || [];
    this._i = 0;
    this._info = info || null;
  }
  fetch() {
    return this._i < this._rows.length ? this._rows[this._i++] : false;
  }
  fetchAll() {
    const out = this._rows.slice(this._i);
    this._i = this._rows.length;
    return out;
  }
  fetchColumn(n = 0) {
    const row = this.fetch();
    if (row === false) return false;
    const vals = Object.values(row);
    return vals[n];
  }
}

const SELECTISH = /^\s*(SELECT|PRAGMA|WITH)/i;

class Stmt {
  constructor(db, sql) {
    this.db = db;
    this.sql = sql;
    this._stmt = db.raw.prepare(sql);
    this._result = new Result([]);
  }
  execute(params = []) {
    const p = (params || []).map(norm);
    if (SELECTISH.test(this.sql)) {
      const rows = this._stmt.all(...p);
      this._result = new Result(rows);
    } else {
      const info = this._stmt.run(...p);
      this.db._lastId = Number(info.lastInsertRowid);
      this.db._changes = Number(info.changes);
      this._result = new Result([], info);
    }
    return this._result;
  }
  fetch() { return this._result.fetch(); }
  fetchAll() { return this._result.fetchAll(); }
  fetchColumn(n = 0) { return this._result.fetchColumn(n); }
}

class DB {
  constructor(rawDb) {
    this.raw = rawDb;
    this._lastId = 0;
    this._changes = 0;
  }
  prepare(sql) { return new Stmt(this, sql); }
  query(sql) { const s = new Stmt(this, sql); s.execute([]); return s; }
  exec(sql) { this.raw.exec(sql); }
  lastInsertId() { return this._lastId; }
  beginTransaction() { this.raw.exec('BEGIN'); }
  commit() { this.raw.exec('COMMIT'); }
  rollBack() { this.raw.exec('ROLLBACK'); }
}

const db = new DB(raw);

// ── Schema (translated from _install/pos_php_fresh.sql to SQLite) ──
const SCHEMA = `
CREATE TABLE IF NOT EXISTS branches (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  name      TEXT NOT NULL,
  address   TEXT DEFAULT '',
  phone     TEXT DEFAULT '',
  status    TEXT DEFAULT 'active',
  createdAt TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS users (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId           INTEGER DEFAULT NULL,
  name               TEXT NOT NULL,
  pin                TEXT NOT NULL DEFAULT '____',
  pin_index          TEXT DEFAULT NULL,
  role               TEXT NOT NULL DEFAULT 'server',
  payRate            REAL DEFAULT 0,
  payType            TEXT DEFAULT 'hourly',
  authMethod         TEXT DEFAULT 'pin',
  passwordHash       TEXT DEFAULT NULL,
  mustChangePassword INTEGER DEFAULT 0,
  isHeld             INTEGER DEFAULT 0,
  username           TEXT DEFAULT NULL,
  UNIQUE (username)
);
CREATE INDEX IF NOT EXISTS idx_pin ON users (pin);
CREATE INDEX IF NOT EXISTS idx_pin_index ON users (pin_index);

CREATE TABLE IF NOT EXISTS settings (
  id                       INTEGER PRIMARY KEY,
  businessName             TEXT DEFAULT 'Restaurant POS',
  logoUrl                  TEXT DEFAULT '',
  businessTagline          TEXT DEFAULT '',
  businessPhone            TEXT DEFAULT '',
  businessAddress          TEXT DEFAULT '',
  businessEmail            TEXT DEFAULT '',
  theme                    TEXT DEFAULT 'light',
  allowUserThemeOverride   INTEGER DEFAULT 1,
  lightThemeId             TEXT DEFAULT 'espresso',
  darkThemeId              TEXT DEFAULT 'slateNight',
  activeThemeId            TEXT DEFAULT 'espresso',
  accentColor              TEXT DEFAULT '#8a5a34',
  accentDark               TEXT DEFAULT '#6e4527',
  accentSoft               TEXT DEFAULT '#f1e4d3',
  font                     TEXT DEFAULT 'Inter',
  currencySymbol           TEXT DEFAULT 'Rs. ',
  serviceChargeRate        REAL DEFAULT 0.1000,
  vatRate                  REAL DEFAULT 0.0800,
  cardFeePercent           REAL DEFAULT 0.0000,
  dateFormat               TEXT DEFAULT 'DD/MM/YYYY',
  lowStockDefaultThreshold INTEGER DEFAULT 5,
  receiptFooterText        TEXT DEFAULT 'Thank you for dining with us!',
  receiptShowVatBreakdown  INTEGER DEFAULT 1,
  notifyEmailEnabled       INTEGER DEFAULT 0,
  notifySmsEnabled         INTEGER DEFAULT 0,
  loginLayout              TEXT DEFAULT 'classic',
  loginBgUrl               TEXT DEFAULT '',
  lastBackupAt             TEXT DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS stations (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId INTEGER NOT NULL,
  name     TEXT NOT NULL,
  color    TEXT DEFAULT '#8a5a34',
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS categories (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId  INTEGER NOT NULL,
  name      TEXT NOT NULL,
  sortOrder INTEGER DEFAULT 0,
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS menu_items (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId  INTEGER NOT NULL,
  name      TEXT NOT NULL,
  price     REAL DEFAULT 0,
  category  TEXT DEFAULT '',
  plu       TEXT DEFAULT NULL,
  imageUrl  TEXT DEFAULT '',
  stationId INTEGER DEFAULT NULL,
  soldOut   INTEGER DEFAULT 0,
  tags      TEXT DEFAULT '',
  recipe    TEXT DEFAULT NULL,
  modifiers TEXT DEFAULT NULL,
  FOREIGN KEY (branchId)  REFERENCES branches(id) ON DELETE CASCADE,
  FOREIGN KEY (stationId) REFERENCES stations(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS tables_list (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId INTEGER NOT NULL,
  name     TEXT NOT NULL,
  seats    INTEGER DEFAULT 4,
  status   TEXT DEFAULT 'open',
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ingredients (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId          INTEGER NOT NULL,
  name              TEXT NOT NULL,
  unit              TEXT DEFAULT 'pcs',
  qty               REAL DEFAULT 0,
  unitCost          REAL DEFAULT 0,
  lowStockThreshold REAL DEFAULT 0,
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS stock_periods (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId      INTEGER NOT NULL,
  label         TEXT NOT NULL,
  startDate     TEXT NOT NULL,
  endDate       TEXT NOT NULL,
  status        TEXT DEFAULT 'closed',
  "lines"       TEXT NOT NULL,
  openingValue  REAL DEFAULT 0,
  purchaseValue REAL DEFAULT 0,
  consumedValue REAL DEFAULT 0,
  closingValue  REAL DEFAULT 0,
  closedByName  TEXT DEFAULT '',
  note          TEXT DEFAULT '',
  createdAt     TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS suppliers (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId INTEGER NOT NULL,
  name     TEXT NOT NULL,
  contact  TEXT DEFAULT '',
  email    TEXT DEFAULT '',
  notes    TEXT DEFAULT '',
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS purchases (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId     INTEGER NOT NULL,
  supplierId   INTEGER DEFAULT NULL,
  supplierName TEXT DEFAULT '',
  items        TEXT NOT NULL,
  total        REAL DEFAULT 0,
  note         TEXT DEFAULT '',
  createdAt    TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId)   REFERENCES branches(id)  ON DELETE CASCADE,
  FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  orderSeqNum       INTEGER DEFAULT NULL,
  branchId          INTEGER NOT NULL,
  orderType         TEXT DEFAULT 'dine-in',
  tableId           INTEGER DEFAULT NULL,
  tableName         TEXT DEFAULT '',
  staffId           INTEGER DEFAULT NULL,
  staffName         TEXT DEFAULT '',
  customerName      TEXT DEFAULT '',
  customerPhone     TEXT DEFAULT '',
  customerAddress   TEXT DEFAULT '',
  note              TEXT DEFAULT '',
  items             TEXT NOT NULL,
  subtotal          REAL DEFAULT 0,
  discount          TEXT DEFAULT NULL,
  serviceCharge     REAL DEFAULT 0,
  vat               REAL DEFAULT 0,
  total             REAL DEFAULT 0,
  status            TEXT DEFAULT 'pending',
  paymentStatus     TEXT DEFAULT 'unpaid',
  priority          TEXT DEFAULT 'normal',
  kitchenTag        TEXT DEFAULT NULL,
  inventoryDeducted INTEGER DEFAULT 0,
  payments          TEXT DEFAULT '[]',
  amountPaid        REAL DEFAULT 0,
  tipAmount         REAL DEFAULT 0,
  void_data         TEXT DEFAULT NULL,
  paidAt            TEXT DEFAULT NULL,
  readyAt           TEXT DEFAULT NULL,
  dispatchedAt      TEXT DEFAULT NULL,
  createdAt         TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS held_orders (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId        INTEGER NOT NULL,
  label           TEXT DEFAULT '',
  staffName       TEXT DEFAULT '',
  orderType       TEXT DEFAULT 'dine-in',
  tableId         INTEGER DEFAULT NULL,
  tableName       TEXT DEFAULT '',
  customerName    TEXT DEFAULT '',
  customerPhone   TEXT DEFAULT '',
  customerAddress TEXT DEFAULT '',
  items           TEXT NOT NULL,
  note            TEXT DEFAULT '',
  priority        TEXT DEFAULT 'normal',
  heldAt          TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS customers (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId  INTEGER NOT NULL,
  phone     TEXT NOT NULL,
  name      TEXT DEFAULT '',
  address   TEXT DEFAULT '',
  createdAt TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE (branchId, phone),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS notifications (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId     INTEGER DEFAULT NULL,
  type         TEXT DEFAULT 'info',
  message      TEXT NOT NULL,
  targetRole   TEXT DEFAULT 'all',
  targetUserId INTEGER DEFAULT NULL,
  relatedId    INTEGER DEFAULT NULL,
  readBy       TEXT DEFAULT '[]',
  createdAt    TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId   INTEGER NOT NULL,
  parentId   INTEGER DEFAULT NULL,
  fromUserId INTEGER NOT NULL,
  fromName   TEXT DEFAULT '',
  fromRole   TEXT DEFAULT '',
  toUserId   INTEGER DEFAULT NULL,
  toName     TEXT DEFAULT '',
  toRole     TEXT DEFAULT NULL,
  body       TEXT NOT NULL,
  readBy     TEXT DEFAULT '[]',
  createdAt  TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS shifts (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId INTEGER NOT NULL,
  userId   INTEGER NOT NULL,
  userName TEXT DEFAULT '',
  clockIn  TEXT NOT NULL,
  clockOut TEXT DEFAULT NULL,
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE,
  FOREIGN KEY (userId)   REFERENCES users(id)    ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS z_reports (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId           INTEGER NOT NULL,
  generatedBy        TEXT DEFAULT '',
  fromDate           TEXT NOT NULL DEFAULT '',
  toDate             TEXT NOT NULL DEFAULT '',
  generatedAt        TEXT DEFAULT (datetime('now','localtime')),
  orderCount         INTEGER DEFAULT 0,
  grossSales         REAL DEFAULT 0,
  totalDiscounts     REAL DEFAULT 0,
  totalServiceCharge REAL DEFAULT 0,
  totalVat           REAL DEFAULT 0,
  netSales           REAL DEFAULT 0,
  paymentBreakdown   TEXT NOT NULL,
  voidedCount        INTEGER DEFAULT 0,
  voidedTotal        REAL DEFAULT 0,
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS petty_cash (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId    INTEGER NOT NULL,
  type        TEXT NOT NULL,
  amount      REAL NOT NULL,
  description TEXT DEFAULT '',
  staffName   TEXT DEFAULT '',
  createdAt   TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS login_logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  userId     INTEGER NOT NULL,
  userName   TEXT DEFAULT '',
  role       TEXT DEFAULT '',
  branchId   INTEGER DEFAULT NULL,
  branchName TEXT DEFAULT '',
  userAgent  TEXT DEFAULT '',
  at         TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS login_rate_limits (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  keyHash TEXT NOT NULL,
  hitAt   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_key_time ON login_rate_limits (keyHash, hitAt);

CREATE TABLE IF NOT EXISTS permissions (
  id                       INTEGER PRIMARY KEY AUTOINCREMENT,
  branchId                 INTEGER NOT NULL,
  serverMaxDiscountPercent REAL DEFAULT 10.00,
  allowServerVoid          INTEGER DEFAULT 0,
  allowCashierVoid         INTEGER DEFAULT 0,
  UNIQUE (branchId),
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS order_sequences (
  branchId     INTEGER NOT NULL PRIMARY KEY,
  currentNum   INTEGER NOT NULL DEFAULT 0,
  lastResetAt  TEXT DEFAULT NULL,
  lastResetNum INTEGER DEFAULT 0,
  FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
);
`;

function migrate() {
  db.exec(SCHEMA);
  // Additive migrations for existing databases (safe no-ops on fresh installs).
  const addCol = (table, col, def) => {
    try { db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`); } catch (e) { /* already exists */ }
  };
  addCol('settings', 'autoStockClose', 'INTEGER DEFAULT 1');
  addCol('settings', 'lastAutoStockCloseMonth', 'TEXT DEFAULT NULL');
  // Separate approval PIN for managers (used to authorise discounts/voids/
  // refunds), kept distinct from the login PIN.
  addCol('users', 'approvalPin', 'TEXT DEFAULT NULL');
  addCol('users', 'approvalPinIndex', 'TEXT DEFAULT NULL');
  // Add-on framework + customer loyalty balance.
  addCol('settings', 'enabledAddons', "TEXT DEFAULT '[]'");
  addCol('customers', 'loyaltyPoints', 'REAL DEFAULT 0');
  // Loyalty add-on configuration (points earning + redemption rates).
  addCol('settings', 'loyaltyEarnPoints', 'REAL DEFAULT 1');   // points earned …
  addCol('settings', 'loyaltyEarnPer', 'REAL DEFAULT 100');    // … per this much spent
  addCol('settings', 'loyaltyRedeemValue', 'REAL DEFAULT 1');  // currency value of 1 point
  addCol('settings', 'loyaltyMinRedeem', 'REAL DEFAULT 0');    // min points before redeeming
  // Mark on the order so points are awarded exactly once.
  addCol('orders', 'loyaltyAwarded', 'INTEGER DEFAULT 0');
  // Automatic promotion applied to an order: {promotionId,name,amount}.
  addCol('orders', 'promo_data', 'TEXT DEFAULT NULL');
  // Promotions add-on.
  db.exec(`CREATE TABLE IF NOT EXISTS promotions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId    INTEGER NOT NULL,
    name        TEXT NOT NULL,
    type        TEXT DEFAULT 'buy_n',    -- buy_n | bundle | daily
    conditions  TEXT DEFAULT '[]',       -- [{menuItemId, qty}]
    rewardKind  TEXT DEFAULT 'percent',  -- percent | amount
    rewardValue REAL DEFAULT 0,
    scope       TEXT DEFAULT 'items',    -- items | order  (for percent rewards)
    days        TEXT DEFAULT '[]',       -- [0..6] weekdays; [] = every day
    active      INTEGER DEFAULT 1,
    priority    INTEGER DEFAULT 0,
    createdAt   TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
  )`);
  // Loyalty activity ledger (earn/redeem/adjust) for reporting + audit.
  db.exec(`CREATE TABLE IF NOT EXISTS loyalty_ledger (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId   INTEGER NOT NULL,
    customerId INTEGER,
    phone      TEXT DEFAULT '',
    orderId    INTEGER,
    type       TEXT DEFAULT 'earn',
    points     REAL DEFAULT 0,
    note       TEXT DEFAULT '',
    byStaffName TEXT DEFAULT '',
    createdAt  TEXT DEFAULT (datetime('now','localtime'))
  )`);
  // Gift cards add-on. A card is scanned/typed by its code at payment.
  db.exec(`CREATE TABLE IF NOT EXISTS gift_cards (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId       INTEGER NOT NULL,
    code           TEXT NOT NULL,
    initialBalance REAL DEFAULT 0,
    balance        REAL DEFAULT 0,
    status         TEXT DEFAULT 'active',
    recipientName  TEXT DEFAULT '',
    note           TEXT DEFAULT '',
    issuedByName   TEXT DEFAULT '',
    createdAt      TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE (branchId, code),
    FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
  )`);
  db.exec(`CREATE TABLE IF NOT EXISTS gift_card_ledger (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId    INTEGER NOT NULL,
    cardId      INTEGER,
    code        TEXT DEFAULT '',
    orderId     INTEGER,
    type        TEXT DEFAULT 'issue',
    amount      REAL DEFAULT 0,
    byStaffName TEXT DEFAULT '',
    createdAt   TEXT DEFAULT (datetime('now','localtime'))
  )`);
  // Full change-audit trail (who changed what, when) — beyond login history.
  db.exec(`CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId   INTEGER,
    userId     INTEGER,
    userName   TEXT DEFAULT '',
    role       TEXT DEFAULT '',
    method     TEXT DEFAULT '',
    path       TEXT DEFAULT '',
    summary    TEXT DEFAULT '',
    statusCode INTEGER,
    ip         TEXT DEFAULT '',
    createdAt  TEXT DEFAULT (datetime('now','localtime'))
  )`);
  // Fiscal / tax-authority foundation.
  addCol('settings', 'taxRegNo', "TEXT DEFAULT ''");          // VAT/TRN registration number
  addCol('settings', 'fiscalEnabled', 'INTEGER DEFAULT 0');    // assign sequential fiscal invoice numbers
  addCol('settings', 'fiscalPrefix', "TEXT DEFAULT 'INV-'");
  addCol('settings', 'fiscalSeq', 'INTEGER DEFAULT 0');
  addCol('orders', 'fiscalNumber', 'TEXT DEFAULT NULL');
  // Thermal print agent (a small local service that drives an ESC/POS printer).
  addCol('settings', 'printAgentUrl', "TEXT DEFAULT ''");
  addCol('settings', 'printAgentEnabled', 'INTEGER DEFAULT 0');
  addCol('settings', 'printPaperWidth', 'INTEGER DEFAULT 48');  // chars per line (48≈80mm, 32≈58mm)
  // QR table ordering: per-table scan-to-order.
  addCol('tables_list', 'qrToken', 'TEXT DEFAULT NULL');
  addCol('settings', 'publicBaseUrl', "TEXT DEFAULT ''");          // address the customer's phone uses
  addCol('settings', 'qrOrderAutoKitchen', 'INTEGER DEFAULT 1');   // 1 = straight to kitchen, 0 = staff accepts first
  addCol('orders', 'source', "TEXT DEFAULT 'staff'");              // staff | online | qr
  addCol('settings', 'defaultOrderType', "TEXT DEFAULT 'dine-in'"); // dine-in | takeaway | delivery
  addCol('settings', 'loginThemeId', "TEXT DEFAULT ''");            // own palette for the login page ('' = match app)
  // Waste / transfer / adjustment tracking for inventory.
  db.exec(`CREATE TABLE IF NOT EXISTS stock_movements (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId       INTEGER NOT NULL,
    ingredientId   INTEGER,
    ingredientName TEXT DEFAULT '',
    type           TEXT DEFAULT 'waste',   -- waste | transfer_out | transfer_in | adjust
    qty            REAL DEFAULT 0,         -- always positive; type gives direction
    unit           TEXT DEFAULT '',
    reason         TEXT DEFAULT '',
    counterpartyBranchId INTEGER,          -- the other branch for a transfer
    byStaffName    TEXT DEFAULT '',
    createdAt      TEXT DEFAULT (datetime('now','localtime'))
  )`);
  // Reservations add-on.
  db.exec(`CREATE TABLE IF NOT EXISTS reservations (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId       INTEGER NOT NULL,
    customerName   TEXT DEFAULT '',
    customerPhone  TEXT DEFAULT '',
    partySize      INTEGER DEFAULT 1,
    reserveDate    TEXT DEFAULT '',     -- YYYY-MM-DD
    reserveTime    TEXT DEFAULT '',     -- HH:MM
    tableId        INTEGER,
    tableName      TEXT DEFAULT '',
    status         TEXT DEFAULT 'booked', -- booked | seated | completed | cancelled | no_show
    note           TEXT DEFAULT '',
    createdByName  TEXT DEFAULT '',
    createdAt      TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (branchId) REFERENCES branches(id) ON DELETE CASCADE
  )`);
}

// ── First-run seed (only when there are no branches yet) ─────
function seedIfEmpty() {
  const count = Number(db.query('SELECT COUNT(*) AS c FROM branches').fetch().c);
  if (count > 0) return;

  db.exec(`
    INSERT INTO settings (id) VALUES (1);

    INSERT INTO branches (id, name, address, phone, status) VALUES
    (1, 'Downtown Branch',   '123 Main Street, Colombo 03', '+94 11 234 5678', 'active'),
    (2, 'Galle Road Branch', '456 Galle Road, Colombo 06',  '+94 11 987 6543', 'active');

    INSERT INTO stations (id, branchId, name, color) VALUES
    (1, 1, 'Grill',     '#e67e22'),
    (2, 1, 'Cold Prep', '#3498db'),
    (3, 1, 'Bar',       '#9b59b6'),
    (4, 2, 'Kitchen',   '#2ecc71');

    INSERT INTO tables_list (branchId, name, seats, status) VALUES
    (1,'Table 1',4,'open'),(1,'Table 2',4,'open'),(1,'Table 3',2,'open'),
    (1,'Table 4',6,'open'),(1,'Table 5',4,'open'),(1,'Table 6',8,'open'),
    (2,'Table A',4,'open'),(2,'Table B',4,'open'),(2,'Table C',6,'open'),
    (2,'Table D',2,'open');

    INSERT INTO ingredients (branchId, name, unit, qty, lowStockThreshold) VALUES
    (1,'Chicken Breast','kg',8,2),
    (1,'Rice','kg',15,3),
    (1,'Curry Sauce','l',5,1),
    (1,'Beef Mince','kg',8,2),
    (1,'Burger Bun','pcs',40,8),
    (1,'Potato','kg',10,2),
    (1,'Flour','kg',10,2),
    (1,'Milk','l',8,1),
    (2,'Burger Bun','pcs',25,5),
    (2,'Beef Patty','pcs',25,5);

    INSERT INTO categories (branchId, name, sortOrder) VALUES
    (1,'Starters',1),(1,'Mains',2),(1,'Biryani',3),
    (1,'Breads',4),(1,'Drinks',5),(1,'Desserts',6),
    (2,'Burgers',1),(2,'Snacks',2),(2,'Drinks',3);

    INSERT INTO permissions (branchId) VALUES (1),(2);

    INSERT INTO users (branchId, name, pin, pin_index, role, payRate, payType, authMethod) VALUES
    (NULL, 'Admin',         '9999', '888df25ae35772424a560c7152a1de794440e0ea5cfee62828333a456a506e05', 'admin',        0.00, 'hourly', 'pin'),
    (NULL, 'Super Manager', '1234', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'superManager', 0.00, 'hourly', 'pin'),
    (1,    'Manager',       '1111', '0ffe1abd1a08215353c233d6e009613e95eec4253832a761af28ff37ac5a150c', 'manager',     50.00, 'hourly', 'pin'),
    (1,    'Server One',    '2222', 'edee29f882543b956620b26d0ee0e7e950399b1c4222f5de05e06425b4c995e9', 'server',      30.00, 'hourly', 'pin'),
    (1,    'Cashier One',   '3333', '318aee3fed8c9d040d35a7fc1fa776fb31303833aa2de885354ddf3d44d8fb69', 'cashier',     30.00, 'hourly', 'pin'),
    (1,    'Kitchen One',   '4444', '79f06f8fde333461739f220090a23cb2a79f6d714bee100d0e4b4af249294619', 'kitchen',     30.00, 'hourly', 'pin');

    INSERT INTO order_sequences (branchId, currentNum) VALUES (1,0),(2,0);
  `);

  // Sample menu items (from _install/sample_data.sql)
  db.exec(`
    INSERT INTO menu_items (branchId, name, price, category, plu, stationId, recipe, modifiers) VALUES
    (1, 'Garlic Bread',   4.50, 'Starters', '101', 2, '[{"ingredientId":1,"qty":1}]', '[{"id":1001,"name":"Add-ons","options":[{"option":"Extra Butter","priceDelta":0.5},{"option":"Cheese","priceDelta":1.0}]}]'),
    (1, 'Spring Rolls',   5.00, 'Starters', '102', 2, '[{"ingredientId":2,"qty":4}]', '[]'),
    (1, 'Chicken Curry',  11.00,'Mains',    '103', 1, '[{"ingredientId":3,"qty":0.3},{"ingredientId":4,"qty":0.2}]', '[{"id":1002,"name":"Spice Level","options":[{"option":"Mild","priceDelta":0},{"option":"Medium","priceDelta":0},{"option":"Hot","priceDelta":0}]}]'),
    (1, 'Veg Fried Rice', 8.50, 'Mains',    '104', 1, '[{"ingredientId":5,"qty":0.25}]','[]'),
    (1, 'Grilled Fish',   13.00,'Mains',    '105', 1, '[{"ingredientId":9,"qty":0.3}]', '[]'),
    (1, 'Mutton Biryani', 14.00,'Biryani',  '106', 1, '[{"ingredientId":8,"qty":0.4},{"ingredientId":10,"qty":0.3}]','[]'),
    (1, 'Chicken Biryani',12.00,'Biryani',  '107', 1, '[{"ingredientId":3,"qty":0.3},{"ingredientId":10,"qty":0.3}]','[]'),
    (1, 'Garlic Naan',    2.00, 'Breads',   '108', 1, '[{"ingredientId":11,"qty":1}]',  '[]'),
    (1, 'Butter Naan',    2.00, 'Breads',   '109', 1, '[{"ingredientId":11,"qty":1}]',  '[]'),
    (1, 'Iced Tea',       2.50, 'Drinks',   '110', 3, '[{"ingredientId":17,"qty":5}]',  '[]'),
    (1, 'Fresh Lime Soda',2.00, 'Drinks',   '111', 3, '[{"ingredientId":18,"qty":1},{"ingredientId":24,"qty":0.1}]','[]'),
    (1, 'Mango Lassi',    3.00, 'Drinks',   '112', 3, '[{"ingredientId":21,"qty":0.2},{"ingredientId":20,"qty":0.1}]','[]'),
    (1, 'Chocolate Cake', 4.50, 'Desserts', '113', 2, '[{"ingredientId":19,"qty":0.1},{"ingredientId":20,"qty":0.1}]','[]'),
    (1, 'Ice Cream',      3.00, 'Desserts', '114', 2, '[{"ingredientId":20,"qty":0.15}]','[]'),
    (2, 'Beef Burger',    9.50, 'Burgers',  '201', 4, '[{"ingredientId":26,"qty":1},{"ingredientId":25,"qty":1}]','[{"id":2001,"name":"Extra","options":[{"option":"Extra Patty","priceDelta":4.0},{"option":"Add Cheese","priceDelta":1.0}]}]'),
    (2, 'Cheese Toastie', 5.00, 'Snacks',   '202', 4, '[{"ingredientId":25,"qty":1}]',  '[]'),
    (2, 'Cola',           1.50, 'Drinks',   '203', 4, '[{"ingredientId":27,"qty":0.15}]','[]');
  `);

  console.log('[db] Seeded starter data (2 branches, demo menu, 6 users).');
}

// Give every table a QR token. Runs after seeding (so seeded tables get one)
// and on every boot (idempotent — only touches tables still missing a token).
function ensureTableTokens() {
  try {
    const rows = db.query("SELECT id FROM tables_list WHERE qrToken IS NULL OR qrToken=''").fetchAll();
    for (const r of rows) {
      let tok = '';
      for (let i = 0; i < 16; i++) tok += 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)];
      db.prepare('UPDATE tables_list SET qrToken=? WHERE id=?').execute([tok, Number(r.id)]);
    }
  } catch (e) { /* ignore */ }
}

migrate();
seedIfEmpty();
ensureTableTokens();

module.exports = { db, DB_FILE, DATA_DIR };
